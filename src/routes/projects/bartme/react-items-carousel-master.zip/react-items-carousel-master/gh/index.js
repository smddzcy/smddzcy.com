import React from 'react';
import ReactDOM from 'react-dom';
import 'antd/dist/antd.css';
import PlaygroundPage from './page';

ReactDOM.render(<PlaygroundPage />, document.getElementById('root'));

import ForwardReplayControl from './ForwardReplayControl';

// Pass mode into parent function
const ForwardControl = ForwardReplayControl('forward');

ForwardControl.displayName = 'ForwardControl';
export default ForwardControl;

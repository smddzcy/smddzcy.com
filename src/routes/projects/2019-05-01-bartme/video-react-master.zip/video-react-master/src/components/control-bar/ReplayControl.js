import ForwardReplayControl from './ForwardReplayControl';

// Pass mode into parent function
const ReplayControl = ForwardReplayControl('replay');
ReplayControl.displayName = 'ReplayControl';

export default ReplayControl;
